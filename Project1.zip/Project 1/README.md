For Debian:
```
$ sudo apt-get install python3-pip
$ sudo apt-get install graphviz
$ sudo -H pip3 install numpy
$ sudo -H pip3 install matplotlib
$ sudo -H pip3 install anytree
$ sudo -H pip3 install graphviz
```

Just Incase
```
$ sudo apt-get install numpy
$ sudo apt-get install matplotlib
```
